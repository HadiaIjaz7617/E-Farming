<?php
// Start session if needed
session_start();

// Retrieve query parameters from URL if any
$quantity = isset($_GET['quantity']) ? intval($_GET['quantity']) : 1;
$imageSrc = isset($_GET['imageSrc']) ? htmlspecialchars($_GET['imageSrc']) : 'corn.jpg';

// Set default product details (for demonstration)
$productName = 'Corn'; // Product name
$unitPrice = 200; // Price per kg
$totalPrice = $unitPrice * $quantity;

// Handle form submission (if needed)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $selectedQuantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;
    $selectedImageSrc = isset($_POST['imageSrc']) ? htmlspecialchars($_POST['imageSrc']) : '';

    // Store order details in session or process as needed
    $_SESSION['order'] = [
        'productName' => $productName,
        'quantity' => $selectedQuantity,
        'totalPrice' => $unitPrice * $selectedQuantity,
        'imageSrc' => $selectedImageSrc
    ];

    // Redirect to order confirmation or another relevant page
    header('Location: order-confirmation-corn.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Corn Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            display: flex;
            max-width: 1000px;
            margin: auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .image-container {
            flex: 1;
            padding: 10px;
        }
        .image-container img {
            max-width: 100%;
            border-radius: 8px;
        }
        .details-container {
            flex: 2;
            padding: 10px;
        }
        .details-container h1 {
            color: #333;
        }
        .details-container p {
            font-size: 18px;
            line-height: 1.6;
        }
        .quantity-controls {
            margin: 20px 0;
            display: flex;
            align-items: center;
        }
        .quantity-controls button {
            font-size: 16px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #eee;
            cursor: pointer;
        }
        .quantity-controls input {
            width: 60px;
            text-align: center;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin: 0 10px;
            padding: 5px;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            font-size: 16px;
            color: #fff;
            background-color: #28a745;
            border: none;
            border-radius: 5px;
            text-align: center;
            text-decoration: none;
            margin: 10px 5px;
            cursor: pointer;
        }
        .btn.add-to-cart {
            background-color: #007bff;
        }
        .btn:hover {
            opacity: 0.9;
        }
        .btn.add-to-cart:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="image-container">
            <img src="<?php echo $imageSrc; ?>" alt="Corn">
        </div>
        <div class="details-container">
            <h1><?php echo $productName; ?></h1>
            <p>Description: Corn is a versatile vegetable that is used in a variety of dishes. It's rich in fiber and nutrients, perfect for meals and snacks.</p>
            <div class="quantity-controls">
                <button id="decrease">-</button>
                <input type="number" id="quantity" value="<?php echo $quantity; ?>" min="1">
                <button id="increase">+</button>
            </div>
            <p id="price">Price: <?php echo $unitPrice; ?>Rs. per kg</p>
            <p id="total-price">Total Price: <?php echo $totalPrice; ?>Rs.</p>
            <a href="order-confirmation-corn.php?quantity=<?php echo $quantity; ?>&imageSrc=<?php echo urlencode($imageSrc); ?>" class="btn">Buy Now</a>
            <form action="corn-details.php" method="post">
                <input type="hidden" name="imageSrc" value="<?php echo htmlspecialchars($imageSrc); ?>">
                <input type="number" name="quantity" value="<?php echo $quantity; ?>" min="1">
                <button type="submit" class="btn add-to-cart">Add to Cart</button>
            </form>
        </div>
    </div>
    <script>
        const unitPrice = <?php echo $unitPrice; ?>;
        const quantityInput = document.getElementById('quantity');
        const totalPriceElement = document.getElementById('total-price');
        const increaseButton = document.getElementById('increase');
        const decreaseButton = document.getElementById('decrease');

        function updatePrice() {
            const quantity = parseInt(quantityInput.value);
            const totalPrice = unitPrice * quantity;
            totalPriceElement.textContent = `Total Price: ${totalPrice}Rs.`;
        }

        increaseButton.addEventListener('click', () => {
            quantityInput.value = parseInt(quantityInput.value) + 1;
            updatePrice();
        });

        decreaseButton.addEventListener('click', () => {
            if (parseInt(quantityInput.value) > 1) {
                quantityInput.value = parseInt(quantityInput.value) - 1;
                updatePrice();
            }
        });

        quantityInput.addEventListener('input', updatePrice);

        updatePrice(); // Initial call to set the correct price on page load
    </script>
</body>
</html>
