<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add to Cart - Chillies</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 1000px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #333;
            margin-bottom: 20px;
        }
        .product {
            margin-bottom: 30px;
            padding: 20px;
            border-bottom: 1px solid #ddd;
        }
        .product img {
            max-width: 100px;
            border-radius: 8px;
            margin-bottom: 10px;
        }
        .quantity-controls {
            margin: 10px 0;
            display: flex;
            align-items: center;
        }
        .quantity-controls button {
            font-size: 16px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #eee;
            cursor: pointer;
        }
        .quantity-controls input {
            width: 60px;
            text-align: center;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin: 0 10px;
            padding: 5px;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            font-size: 16px;
            color: #fff;
            background-color: #28a745;
            border: none;
            border-radius: 5px;
            text-align: center;
            text-decoration: none;
            margin: 10px 5px;
            cursor: pointer;
        }
        .btn.add-to-cart {
            background-color: #007bff;
        }
        .btn:hover {
            opacity: 0.9;
        }
        .btn.add-to-cart:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Add to Cart - Chillies</h1>

        <!-- Product Section -->
        <div class="product" id="chillies-section">
            <h2>Chillies</h2>
            <img src="chilii.jpg" alt="Chillies">
            <p>Description: Chillies add a spicy kick to your dishes and are packed with flavor. Our chillies are fresh and high-quality, perfect for spicing up any meal.</p>
            <div class="quantity-controls">
                <button data-product="chillies" class="decrease">-</button>
                <input type="number" data-product="chillies" class="quantity" value="1" min="1">
                <button data-product="chillies" class="increase">+</button>
            </div>
            <p class="price">Price: 500Rs. per kg</p>
            <p class="total-price">Total Price: 500Rs.</p>
        </div>

        <a href="#" class="btn" id="proceed-to-checkout">Proceed to Checkout</a>
    </div>

    <script>
        const prices = {
            chillies: 500, // Price per kg for chillies
        };

        const updatePrice = (product) => {
            const quantityInput = document.querySelector(`input[data-product="${product}"]`);
            const totalPriceElement = document.querySelector(`#${product}-section .total-price`);
            const quantity = parseInt(quantityInput.value, 10);
            const totalPrice = prices[product] * quantity;
            totalPriceElement.textContent = `Total Price: ${totalPrice}Rs.`;
        };

        document.querySelectorAll('.increase').forEach(button => {
            button.addEventListener('click', () => {
                const product = button.getAttribute('data-product');
                const quantityInput = document.querySelector(`input[data-product="${product}"]`);
                quantityInput.value = parseInt(quantityInput.value, 10) + 1;
                updatePrice(product);
            });
        });

        document.querySelectorAll('.decrease').forEach(button => {
            button.addEventListener('click', () => {
                const product = button.getAttribute('data-product');
                const quantityInput = document.querySelector(`input[data-product="${product}"]`);
                if (parseInt(quantityInput.value, 10) > 1) {
                    quantityInput.value = parseInt(quantityInput.value, 10) - 1;
                    updatePrice(product);
                }
            });
        });

        document.querySelectorAll('.quantity').forEach(input => {
            input.addEventListener('input', () => {
                const product = input.getAttribute('data-product');
                updatePrice(product);
            });
        });

        document.getElementById('proceed-to-checkout').addEventListener('click', (event) => {
            event.preventDefault();
            let queryParams = [];
            document.querySelectorAll('.product').forEach(productSection => {
                const product = productSection.id.split('-')[0];
                const quantity = productSection.querySelector(`input[data-product="${product}"]`).value;
                const imageSrc = productSection.querySelector('img').src;

                if (quantity > 0) {
                    queryParams.push(`product=${product}&quantity=${quantity}&imageSrc=${encodeURIComponent(imageSrc)}`);
                }
            });

            const confirmationUrl = `order-confirmation-chilli.php?${queryParams.join('&')}`;
            window.location.href = confirmationUrl;
        });
    </script>
</body>
</html>
