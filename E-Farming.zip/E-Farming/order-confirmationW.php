<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation</title>
    
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #d2c3ab;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        h1 {
            color: #333;
            margin-bottom: 20px;
        }
        p {
            font-size: 18px;
            line-height: 1.6;
        }
        .product-image {
            max-width: 100px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .payment-options {
            margin: 20px 0;
        }
        .payment-options label {
            font-size: 18px;
            margin-right: 10px;
        }
        .payment-options input {
            margin-right: 5px;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            font-size: 16px;
            color: #fff;
            background-color: #28a745;
            border: none;
            border-radius: 5px;
            text-align: center;
            text-decoration: none;
            margin: 10px 5px;
            cursor: pointer;
        }
        .btn:hover {
            opacity: 0.9;
            background-color: #8f7e29;
        }
    </style>
</head>
<body>
  
    <div class="container">
        <h1>Order Confirmation</h1>
        <?php
            // Retrieve the query parameters from the URL
            $quantity = isset($_GET['quantity']) ? intval($_GET['quantity']) : 1;
            $imageSrc = isset($_GET['imageSrc']) ? htmlspecialchars($_GET['imageSrc']) : 'default-image.png';

            // Define the unit price
            $unitPrice = 100; // Price per kg

            // Calculate the total price
            $totalPrice = $unitPrice * $quantity;
        ?>
        <img id="product-image" src="<?php echo $imageSrc; ?>" alt="Product Image" class="product-image">
        <p>Your order for <strong>Wheat</strong> has been placed successfully.</p>
        <p id="total-amount">Total Amount: <?php echo $totalPrice; ?> Rs.</p>
        <div class="payment-options">
            <h2>Select Payment Method:</h2>
            <label>
                <input type="radio" name="payment" value="card"> Credit/Debit Card
            </label><br>
            <label>
                <input type="radio" name="payment" value="cash"> Cash on Delivery
            </label><br>
            <label>
                <input type="radio" name="payment" value="online"> Online Payment
            </label>
        </div>
        <a href="#" class="btn">Confirm Order</a>
    </div>

</body>
</html>
