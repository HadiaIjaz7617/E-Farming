<?php
// Define guidelines and images
$guidelines = [
    [
        'title' => 'Adopt Sustainable Farming Practices',
        'image' => 'farm.jpg',
        'items' => [
            'Crop Rotation: Rotate different crops to improve soil health and reduce pest infestations.',
            'Cover Cropping: Use cover crops to prevent soil erosion, improve soil fertility, and manage weeds.',
            'Conservation Tillage: Minimize tillage to protect soil structure and reduce erosion.'
        ]
    ],
    [
        'title' => 'Implement Precision Agriculture',
        'image' => 'agriculture.jpg',
        'items' => [
            'Soil Testing: Regularly test soil to determine nutrient levels and pH to optimize fertilizer application.',
            'GPS and GIS Technologies: Use GPS for precise planting, and GIS for analyzing field conditions.',
            'Variable Rate Technology (VRT): Apply inputs such as fertilizers and pesticides at variable rates to match field variability.'
        ]
    ],
    [
        'title' => 'Efficient Water Management',
        'image' => 'water.jpg',
        'items' => [
            'Drip Irrigation: Implement drip irrigation to provide water directly to the plant roots, reducing water usage and improving efficiency.',
            'Rainwater Harvesting: Collect and store rainwater for irrigation purposes.',
            'Soil Moisture Sensors: Use sensors to monitor soil moisture levels and optimize irrigation schedules.'
        ]
    ],
    [
        'title' => 'Integrated Pest Management (IPM)',
        'image' => 'pest.jpg',
        'items' => [
            'Biological Control: Use natural predators and parasites to control pests.',
            'Cultural Practices: Alter farming practices, such as crop rotation and intercropping, to reduce pest populations.',
            'Chemical Control: Use pesticides judiciously and only when necessary, following recommended guidelines.'
        ]
    ],
    [
        'title' => 'Use of Improved Seeds and Plant Varieties',
        'image' => 'seeds.jpg',
        'items' => [
            'High-Yield Varieties: Plant high-yield and disease-resistant crop varieties.',
            'Genetically Modified Crops: Consider GM crops for traits such as pest resistance and drought tolerance.',
            'Seed Treatment: Treat seeds with fungicides and insecticides to protect young plants.'
        ]
    ],
    [
        'title' => 'Enhance Soil Health',
        'image' => 'soil.jpg',
        'items' => [
            'Organic Matter: Add organic matter such as compost and manure to improve soil structure and fertility.',
            'Soil Conservation: Implement practices to prevent soil erosion, such as contour plowing and terracing.',
            'Cover Crops: Grow cover crops to improve soil organic matter and prevent erosion.'
        ]
    ],
    [
        'title' => 'Implement Modern Technology',
        'image' => 'technologies.jpg',
        'items' => [
            'Drones: Use drones for monitoring crop health, mapping fields, and applying inputs.',
            'IoT Devices: Use Internet of Things (IoT) devices for real-time monitoring of environmental conditions.',
            'Data Analytics: Use data analytics to make informed decisions based on historical data and predictive models.'
        ]
    ],
    [
        'title' => 'Diversify Farming Activities',
        'image' => 'animals.jpg',
        'items' => [
            'Crop Diversification: Grow a variety of crops to reduce risk and improve soil health.',
            'Livestock Integration: Integrate livestock with crop production to enhance nutrient cycling and farm income.',
            'Agroforestry: Combine trees and shrubs with crops and livestock to create more diverse, productive, and sustainable land-use systems.'
        ]
    ]
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agriculture Improvement Guidelines</title>
    <link rel="stylesheet" href="stylesheet.css">
</head>
<body>
   
    <header>
        <h1>e-Farming</h1>
        <h2>Agriculture Improvement Guidelines</h2>
        <div class="header-container">
            <nav>
                <ul>
                    <li><a href="index.html#home">Home</a></li>
                    <li><a href="index.html#about-us">About</a></li>
                    <li><a href="index.html#services">Services</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <?php foreach ($guidelines as $guideline): ?>
    <section>
        <h2><?php echo $guideline['title']; ?></h2>
        <img src="<?php echo $guideline['image']; ?>" alt="<?php echo htmlspecialchars($guideline['title']); ?>">
        <ul>
            <?php foreach ($guideline['items'] as $item): ?>
                <li><b><?php echo htmlspecialchars($item); ?></b></li>
            <?php endforeach; ?>
        </ul>
    </section>
    <?php endforeach; ?>

    <footer>
        <p>&copy; 2024 Agriculture Improvement. All rights reserved.</p>
    </footer>
</body>
</html>
