<?php
// List of products with their details
$products = [
    [
        'name' => 'Apple',
        'url' => 'apple.php',
        'image' => 'apple.jpg',
        'price' => '300Rs. per kg'
    ],
    [
        'name' => 'Banana',
        'url' => 'banana.php',
        'image' => 'banana.jpg',
        'price' => '250Rs. per dozen'
    ],
    [
        'name' => 'Wheat',
        'url' => 'wheat.php',
        'image' => 'wheat.png',
        'price' => '100Rs. per kg'
    ],
    [
        'name' => 'Rice',
        'url' => 'rice.php',
        'image' => 'rice.jpg',
        'price' => '150Rs. per kg'
    ],
    [
        'name' => 'Corn',
        'url' => 'corn.php',
        'image' => 'corn.jpg',
        'price' => '200Rs. per kg'
    ],
    [
        'name' => 'Chili',
        'url' => 'chili.php',
        'image' => 'chilii.jpg',
        'price' => '500Rs. per kg'
    ],
    [
        'name' => 'Orange',
        'url' => 'orange.php',
        'image' => 'oranges.jfif',
        'price' => '300Rs. per dozen'
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <section id="products">
        <div class="header-container">
            <h1 style="color: black">e-Farming</h1>
            <nav>
                <ul>
                    <li><a href="index.php#home" style="color: black">Home</a></li>
                    <li><a href="index.php#about-us" style="color: black">About</a></li>
                    <li><a href="index.php#services" style="color: black">Services</a></li>
                    <li><a href="products.php" style="color: black">Products</a></li> <!-- Highlighted Products link -->
                </ul>
            </nav>
        </div>
        <h2>Our Products</h2>
        <?php foreach ($products as $product): ?>
            <div class="product">
                <a href="<?php echo $product['url']; ?>">
                    <img src="<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>">
                    <p>Stock "available" <br> Price: <?php echo $product['price']; ?></p>
                </a>
            </div>
        <?php endforeach; ?>
    </section>
</body>
</html>
