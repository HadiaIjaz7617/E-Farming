<?php include 'header.php'; ?>

<section id="about-us" class="about-us">
    <div class="container">
        <h2>About Us</h2>
        <p>We are dedicated to transforming agriculture through innovative technology. Our mission is to empower farmers with tools that improve efficiency, productivity, and sustainability.</p>
    </div>
</section>
<section id="testimonials" class="testimonials">
    <div class="container">
        <h2>What Our Customers Say</h2>
        <div class="testimonial">
            <blockquote>
                <p>"E-Farming Solutions has revolutionized the way we manage our farm. The tools are intuitive and effective."</p>
                <br><p><b>- Jamie Taylor</b></p>
            </blockquote>
        </div>
        <div class="testimonial">
            <blockquote>
                <p>"A game-changer for modern agriculture. Highly recommended for any farmer looking to enhance their operations."</p>
                <b>- Jordan Lee</b>
            </blockquote>
        </div>
    </div>
</section>

<section id="services">
    <h2>Our Services</h2>
    <div class="service-item">
        <a href="login-page">
            <img src="img1.jpg" alt="Buy or sell at your terms">
        </a>
        <p>Buy or sell at your terms</p>
        <a href="login-page.php"></a>
    </div>
    <a href="login.php" class="service-item">
        <img src="img2.jpg" alt="Guidelines for improving agriculture">
        <p>Guidelines for improving agriculture</p>
    </a>
    
</section>

<?php include 'footer.php'; ?>
