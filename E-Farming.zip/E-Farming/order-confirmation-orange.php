<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation - Oranges</title>
    <style>
        /* Similar styling as in the Add to Cart page for consistency */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        h1 {
            color: #333;
            margin-bottom: 20px;
        }
        img {
            max-width: 100px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        p {
            font-size: 18px;
            margin: 10px 0;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            font-size: 16px;
            color: #fff;
            background-color: #28a745;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            cursor: pointer;
            margin-top: 20px;
        }
        .btn:hover {
            opacity: 0.9;
        }
    </style>
</head>
<body>
    <?php
        // Retrieve query parameters
        $product = isset($_GET['product']) ? htmlspecialchars($_GET['product']) : 'Oranges';
        $quantity = isset($_GET['quantity']) ? intval($_GET['quantity']) : 1;
        $imageSrc = isset($_GET['imageSrc']) ? htmlspecialchars($_GET['imageSrc']) : 'default-image.png';
        $pricePerUnit = 300; // Price per dozen for oranges
        $totalAmount = $pricePerUnit * $quantity;
    ?>
    <div class="container">
        <h1>Order Confirmation - <?php echo ucfirst($product); ?></h1>
        <img id="product-image" src="<?php echo $imageSrc; ?>" alt="<?php echo ucfirst($product); ?>">
        <p id="confirmation-message">Your order for <?php echo ucfirst($product); ?> has been placed successfully.</p>
        <p id="total-amount">Total Amount: <?php echo $totalAmount; ?> Rs.</p>

        <h3>Select Payment Method:</h3>
        <form>
            <input type="radio" id="credit" name="payment" value="Credit/Debit Card">
            <label for="credit">Credit/Debit Card</label><br>
            <input type="radio" id="cash" name="payment" value="Cash on Delivery">
            <label for="cash">Cash on Delivery</label><br>
            <input type="radio" id="online" name="payment" value="Online Payment">
            <label for="online">Online Payment</label><br><br>
            <button class="btn" type="submit">Confirm Order</button>
        </form>
    </div>
</body>
</html>
