<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "products"; 

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query example
$sql = "INSERT INTO products (name, description, price, image, stock) VALUES ('Apple', 'Apples are a rich source of vitamins and fiber...', 300.00, 'apple.jpg', 100)";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
 