<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>e-Farming</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <section id="home">
        <div class="header-container">
            <h1>e-Farming</h1>
            <nav>
                <ul>
                    <li><a href="index.php#home">Home</a></li>
                    <li><a href="index.php#about-us">About</a></li>
                    <li><a href="index.php#services">Services</a></li>
                    <li><a href="products.php">Products</a></li>
                </ul>
            </nav>
        </div>
        <div class="content">
            <h2>Transforming the agricultural values <br>through technology</h2>
        </div>
    </section>
