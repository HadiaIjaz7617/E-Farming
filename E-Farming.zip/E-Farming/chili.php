<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chilli Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            display: flex;
            max-width: 1000px;
            margin: auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .image-container {
            flex: 1;
            padding: 10px;
        }
        .image-container img {
            max-width: 100%;
            border-radius: 8px;
        }
        .details-container {
            flex: 2;
            padding: 10px;
        }
        .details-container h1 {
            color: #333;
        }
        .details-container p {
            font-size: 18px;
            line-height: 1.6;
        }
        .quantity-controls {
            margin: 20px 0;
            display: flex;
            align-items: center;
        }
        .quantity-controls button {
            font-size: 16px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #eee;
            cursor: pointer;
        }
        .quantity-controls input {
            width: 60px;
            text-align: center;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin: 0 10px;
            padding: 5px;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            font-size: 16px;
            color: #fff;
            background-color: #28a745;
            border: none;
            border-radius: 5px;
            text-align: center;
            text-decoration: none;
            margin: 10px 5px;
            cursor: pointer;
        }
        .btn.add-to-cart {
            background-color: #007bff;
        }
        .btn:hover {
            opacity: 0.9;
        }
        .btn.add-to-cart:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <?php
        $pricePerKg = 500; // Price per kg
        $imageSrc = 'chilii.jpg'; // Image source
    ?>
    <div class="container">
        <div class="image-container">
            <img src="<?php echo $imageSrc; ?>" alt="Chilli">
        </div>
        <div class="details-container">
            <h1>Chilli</h1>
            <p>Description: Chillies add spice and flavor to your dishes. They are rich in vitamins and antioxidants, making them a great addition to many recipes.</p>
            <div class="quantity-controls">
                <button id="decrease">-</button>
                <input type="number" id="quantity" value="1" min="1">
                <button id="increase">+</button>
            </div>
            <p id="price">Price: <?php echo $pricePerKg; ?>Rs. per kg</p>
            <p id="total-price">Total Price: <?php echo $pricePerKg; ?>Rs.</p>
            <a href="#" id="buy-now" class="btn">Buy Now</a>
            <a href="add-to-cart.php?product=chilli&imageSrc=<?php echo urlencode($imageSrc); ?>" class="btn add-to-cart">Add to Cart</a>
        </div>
    </div>
    <script>
        const unitPrice = <?php echo $pricePerKg; ?>; // Price per kg from PHP
        const quantityInput = document.getElementById('quantity');
        const totalPriceElement = document.getElementById('total-price');
        const increaseButton = document.getElementById('increase');
        const decreaseButton = document.getElementById('decrease');
        const buyNowButton = document.getElementById('buy-now');

        function updatePrice() {
            const quantity = parseInt(quantityInput.value);
            const totalPrice = unitPrice * quantity;
            totalPriceElement.textContent = `Total Price: ${totalPrice}Rs.`;
            
            // Update the Buy Now link's href with the new quantity and imageSrc
            buyNowButton.href = `order-confirmation-chilli.php?product=chilli&quantity=${quantity}&imageSrc=${encodeURIComponent('<?php echo $imageSrc; ?>')}`;
        }

        increaseButton.addEventListener('click', () => {
            quantityInput.value = parseInt(quantityInput.value) + 1;
            updatePrice();
        });

        decreaseButton.addEventListener('click', () => {
            if (parseInt(quantityInput.value) > 1) {
                quantityInput.value = parseInt(quantityInput.value) - 1;
                updatePrice();
            }
        });

        quantityInput.addEventListener('input', updatePrice);

        // Initial call to set the correct href on page load
        updatePrice();
    </script>
</body>
</html>
