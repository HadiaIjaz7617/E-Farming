<?php
// Start session to manage user data
session_start();

// Check if role is provided via URL parameters
$role = isset($_GET['role']) ? htmlspecialchars($_GET['role']) : '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $username = isset($_POST['username']) ? htmlspecialchars($_POST['username']) : '';
    $password = isset($_POST['password']) ? htmlspecialchars($_POST['password']) : '';
    $formRole = isset($_POST['role']) ? htmlspecialchars($_POST['role']) : '';

    // Here you would typically handle user authentication
    // For demonstration, we'll just save role and redirect

    $_SESSION['username'] = $username;
    $_SESSION['role'] = $formRole; // Store the role in session

    // Redirect to products page (or any other page as needed)
    header('Location: products.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <section id="login">
        <h2>Login</h2>
        <form action="login.php" method="post">
            <input type="hidden" name="role" value="<?php echo htmlspecialchars($role); ?>" id="role-input">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <button type="submit">Login</button>
        </form>
    </section>
</body>
</html>
