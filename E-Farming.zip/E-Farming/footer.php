    <section id="contact">
        <h2>Contact Us</h2>
        <div class="contact-icons">
            <a href="mailto:info@efarming.com"><img src="email.png" alt="Email"></a>
            <a href="tel:+8801717306362"><img src="phone.png" alt="Phone"></a>
            <a href="#"><img src="facebook.webp" alt="Facebook"></a>
            <a href="#"><img src="x.png" alt="X"></a>
            <a href="#"><img src="linkedin.png" alt="LinkedIn"></a>
            <a href="#"><img src="youtube.png" alt="YouTube"></a>
        </div>
    </section>

    <footer>
        <p>&copy; 2024 e-Farming. All rights reserved.</p>
    </footer>
</body>
</html>
